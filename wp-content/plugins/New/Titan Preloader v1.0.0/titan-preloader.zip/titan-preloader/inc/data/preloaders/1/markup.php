<div class="gfx_preloader">
    <div class="gfx_preloader--bg gfx_preloader--bg-1"></div>
    <div class="gfx_preloader--bg gfx_preloader--bg-2"></div>
    <div class="gfx_preloader--bg gfx_preloader--bg-3"></div>
    <div class="gfx_preloader--bg gfx_preloader--bg-4"></div>
    <div class="gfx_preloader--countdown" data-count="3">3</div>
    __PATTERN__
</div>