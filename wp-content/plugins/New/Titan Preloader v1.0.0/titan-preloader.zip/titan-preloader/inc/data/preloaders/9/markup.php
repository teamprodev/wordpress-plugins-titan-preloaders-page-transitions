<div class="gfx_preloader">
    <div class="gfx_preloader--bg"></div>
    __PATTERN__
    <div class="gfx_preloader--inner">
        <div class="gfx_preloader--ball"></div>
        <div class="gfx_preloader--shadow"></div>
    </div>
</div>
