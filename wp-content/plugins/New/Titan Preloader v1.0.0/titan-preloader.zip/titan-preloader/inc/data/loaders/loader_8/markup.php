<div class="gfx_preloader--loader">
    <div class="gfx_preloader--loader-circle-1"></div>
    <div class="gfx_preloader--loader-circle-2"></div>
    <div class="gfx_preloader--loader-circle-3"></div>
</div>