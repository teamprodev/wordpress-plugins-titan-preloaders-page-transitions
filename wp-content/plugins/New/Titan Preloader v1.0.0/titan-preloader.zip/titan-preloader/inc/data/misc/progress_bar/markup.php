<div class="gfx_preloader--progress-bar">
    <div class="gfx_preloader--progress-actual"></div>
</div>