<div class="gfx_preloader-icon">
    <div class="gfx_preloader-icon-container">
        <span class="gfx_preloader-animated-preloader"></span>
    </div>
</div>