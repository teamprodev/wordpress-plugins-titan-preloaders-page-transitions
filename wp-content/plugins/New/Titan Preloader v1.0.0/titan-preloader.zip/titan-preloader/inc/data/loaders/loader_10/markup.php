<div class="gfx_preloader--loader">
    <div class="gfx_preloader--loader-1"></div>
    <div class="gfx_preloader--loader-2"></div>
    <div class="gfx_preloader--loader-3"></div>
    <div class="gfx_preloader--loader-4"></div>
    <div class="gfx_preloader--loader-5"></div>
    <div class="gfx_preloader--loader-6"></div>
    <div class="gfx_preloader--loader-7"></div>
    <div class="gfx_preloader--loader-8"></div>
    <div class="gfx_preloader--loader-9"></div>
</div>