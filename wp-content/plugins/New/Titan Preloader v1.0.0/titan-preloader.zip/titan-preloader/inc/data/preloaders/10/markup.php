<div class="gfx_preloader">
    <div class="gfx_preloader-wrapper">
        <div class="gfx_preloader--numbers-wrapper">        
            <div class="gfx_preloader--numbers gfx_preloader--numbers-1">  
                <div class="gfx_preloader--numbers-inner">
                    <div class="gfx_preloader--number">0</div>
                    <div class="gfx_preloader--number">1</div>
                    <div class="gfx_preloader--number">2</div>
                    <div class="gfx_preloader--number">3</div>
                    <div class="gfx_preloader--number">4</div>
                    <div class="gfx_preloader--number">5</div>
                    <div class="gfx_preloader--number">6</div>
                    <div class="gfx_preloader--number">7</div>
                    <div class="gfx_preloader--number">8</div>
                    <div class="gfx_preloader--number">9</div>
                </div>
            </div>

            <div class="gfx_preloader--numbers gfx_preloader--numbers-2">
                <div class="gfx_preloader--numbers-inner">
                    <div class="gfx_preloader--number">0</div>
                    <div class="gfx_preloader--number">1</div>
                    <div class="gfx_preloader--number">2</div>
                    <div class="gfx_preloader--number">3</div>
                    <div class="gfx_preloader--number">4</div>
                    <div class="gfx_preloader--number">5</div>
                    <div class="gfx_preloader--number">6</div>
                    <div class="gfx_preloader--number">7</div>
                    <div class="gfx_preloader--number">8</div>
                    <div class="gfx_preloader--number">9</div>
                </div>
            </div>

        </div>

        <div class="gfx_preloader--percent">%</div>
    </div>
</div>
