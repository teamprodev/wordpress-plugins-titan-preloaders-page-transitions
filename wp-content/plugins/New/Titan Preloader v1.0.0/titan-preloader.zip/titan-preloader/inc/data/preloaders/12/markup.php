<div class="gfx_preloader">
    __PATTERN__
    <div class="gfx_preloader--inner">
        __REPEATER_CONTENT__
        <div class="gfx_preloader--box"></div>
    </div>
</div>
